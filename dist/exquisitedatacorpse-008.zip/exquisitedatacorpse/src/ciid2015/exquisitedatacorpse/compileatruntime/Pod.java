package ciid2015.exquisitedatacorpse.compileatruntime;

import processing.core.PApplet;

public interface Pod {

    void setup(PApplet p);

    void draw(PApplet p);
}
