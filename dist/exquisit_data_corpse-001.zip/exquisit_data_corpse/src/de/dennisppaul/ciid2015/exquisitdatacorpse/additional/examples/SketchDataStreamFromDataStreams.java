package de.dennisppaul.ciid2015.exquisitdatacorpse.additional.examples;

public class SketchDataStreamFromDataStreams {

}
