package ciid2015.exquisitdatacorpse.compileatruntime;

import processing.core.PApplet;

public interface Pod {

    void setup(PApplet p);

    void draw(PApplet p);
}
